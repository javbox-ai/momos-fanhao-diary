import requests
from jinja2 import Environment, FileSystemLoader
import os
import mysql.connector # 新增
from datetime import datetime # 新增
import re # 新增，用於生成安全的文件名
import json # 新增，用於處理 JSON

# --- 資料庫連接資訊 (從 app.py 複製並調整) ---
DATABASE_CONFIG = {
    'host': os.getenv('DB_HOST', 'localhost'),
    'user': os.getenv('DB_USER', 'root'),
    'password': os.getenv('DB_PASSWORD', 'yoyo0024'),
    'database': os.getenv('DB_DATABASE', 'missav_db')
}

connection_config = {
    'user': DATABASE_CONFIG['user'],
    'password': DATABASE_CONFIG['password'],
    'host': DATABASE_CONFIG['host'],
    'database': DATABASE_CONFIG['database']
}

# --- DeepSeek API 設定 ---
# !! 從環境變數讀取 API Key !!
DEEPSEEK_API_KEY = os.getenv('DEEPSEEK_API_KEY', "sk-dc0e894e0fe041a2b251b0694cba0b79") # 使用環境變數，保留原始值作為備用
DEEPSEEK_API_URL = os.getenv('DEEPSEEK_API_URL', "https://api.deepseek.com/v1/chat/completions")

# --- 資料庫操作函數 (從 app.py 複製並調整) ---
def get_db_connection():
    """建立並返回資料庫連接"""
    try:
        conn = mysql.connector.connect(**connection_config)
        print("資料庫連接成功")
        return conn
    except Exception as e:
        print(f"資料庫連接錯誤: {e}")
        return None

def fetch_top_video_details(): # 移除 limit 和 offset
    """從資料庫獲取前 N 筆影片的詳細資訊 (依 ID 排序)"""
    conn = get_db_connection()
    if not conn:
        return None
    video_detail = None
    try:
        cursor = conn.cursor(dictionary=True)
        # 查詢第一筆影片 (依 id 升序)
        query = """
            SELECT
                v.code AS id,
                v.title,
                v.cover_url AS cover_image,
                v.description, # 原始簡介
                v.release_date,
                GROUP_CONCAT(DISTINCT a.name) AS actresses, # 獲取所有女優名
                GROUP_CONCAT(DISTINCT g.name) AS genres,    # 獲取所有類型名
                GROUP_CONCAT(DISTINCT s.name) AS series,    # 獲取所有系列名
                GROUP_CONCAT(DISTINCT l.name) AS labels     # 獲取所有標籤名
            FROM videos v
            LEFT JOIN video_actress va ON v.id = va.video_id
            LEFT JOIN actresses a ON va.actress_id = a.id
            LEFT JOIN video_genre vg ON v.id = vg.video_id
            LEFT JOIN genres g ON vg.genre_id = g.id
            LEFT JOIN video_series vs ON v.id = vs.video_id
            LEFT JOIN series s ON vs.series_id = s.id
            LEFT JOIN video_label vl ON v.id = vl.video_id
            LEFT JOIN labels l ON vl.label_id = l.id
            GROUP BY v.id
            ORDER BY v.id ASC
            LIMIT 3 # Fetch only the first 3 videos
        """
        cursor.execute(query) # Removed limit and offset parameters
        video_details = cursor.fetchall() # 獲取所有結果

        processed_details = []
        if video_details:
            print(f"從資料庫成功獲取 {len(video_details)} 筆影片的詳細資訊")
            for video_detail in video_details: # 遍歷每一筆資料
                print(f"  處理影片 {video_detail['id']}...")
                # 處理空值和轉換格式
                if not video_detail['cover_image']:
                    # 注意：這裡不能直接用 url_for，因為不在 Flask 上下文中
                    # 可以設置一個預設的靜態路徑或 URL
                    video_detail['cover_image'] = '/static/placeholder.jpg' # 或其他預設圖片 URL
                # 將逗號分隔的字串轉換為列表
                for key in ['actresses', 'genres', 'series', 'labels']:
                    if video_detail[key]:
                        video_detail[key] = video_detail[key].split(',')
                    else:
                        video_detail[key] = []
                # 將 release_date 轉換為字串
                if video_detail['release_date'] and isinstance(video_detail['release_date'], datetime):
                     video_detail['release_date'] = video_detail['release_date'].strftime('%Y-%m-%d')
                elif not video_detail['release_date']:
                     video_detail['release_date'] = 'N/A'

                # --- 數據映射以匹配模板期望 --- 
                # 直接使用資料庫的 title
                # video_detail['title_zh'] = video_detail.get('title', '未知標題') # 不再需要
                # video_detail['title_en'] = video_detail.get('title', 'Unknown Title') # 不再需要

                # 模板需要 'actress' (單數)，取第一個女優
                # video_detail['actress'] = video_detail['actresses'][0] if video_detail['actresses'] else '未知演員'
                # 改為英文預設值
                video_detail['actress'] = video_detail['actresses'][0] if video_detail['actresses'] else 'Unknown Actress'

                # 模板需要 'category'，我們用第一個 genre
                # video_detail['category'] = video_detail['genres'][0] if video_detail['genres'] else '未知類別'
                # 改為英文預設值
                video_detail['category'] = video_detail['genres'][0] if video_detail['genres'] else 'Unknown Category'

                # 模板需要 'tags' (字串)，我們將 genres 列表合併
                video_detail['tags'] = ','.join(video_detail['genres']) if video_detail['genres'] else ''

                # 模板需要 'duration'，資料庫目前沒有，設為預設值
                video_detail['duration'] = video_detail.get('duration', 'N/A') # 或從其他地方獲取

                # 用於 AI prompt 的基礎資訊
                video_detail['base_info_for_ai'] = video_detail.get('description', '')
                processed_details.append(video_detail) # 將處理好的資料加入列表

        else:
            print("在資料庫中找不到任何影片")

    except mysql.connector.Error as err:
        print(f"查詢第一筆影片詳細資訊時發生錯誤: {err}")
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()
            print("資料庫連接已關閉")
    return processed_details # 返回處理後的列表

# --- 輔助函數：生成 Schema.org JSON-LD --- 
def generate_schema_data(video_data, lang, base_url="https://example.com"): # 假設基礎 URL
    """根據影片資料生成 Schema.org JSON-LD"""
    # 確保 video_data['id'] 存在且不為空
    video_id = video_data.get('id')
    if not video_id:
        print(f"警告：影片缺少 ID，無法生成有效的頁面 URL。Video data: {video_data}")
        return None # 或者返回一個空的 schema
        
    page_url = f"{base_url}/output/{video_id}_{lang}.html"
    
    schema = {
        "@context": "https://schema.org",
        "@graph": [
            {
                "@type": "Review",
                "itemReviewed": {
                    "@type": "Movie", # 或 VideoObject
                    "name": video_data.get('title', ''),
                    "identifier": video_id,
                    "datePublished": video_data.get('release_date', '') if video_data.get('release_date') != 'N/A' else None,
                    "director": None, # 如果有導演資訊可以加入
                    "actor": [{"@type": "Person", "name": actress} for actress in video_data.get('actresses', [])],
                    "genre": video_data.get('genres', []),
                    "image": video_data.get('cover_image', '') if video_data.get('cover_image', '').startswith('http') else None, # 確保是絕對 URL
                    "description": video_data.get('base_info_for_ai', '') # 使用 AI prompt 的基礎資訊作為描述
                },
                "author": {
                    "@type": "Person",
                    "name": "Momo" # 網站作者名
                },
                "reviewBody": video_data.get('ai_content', ''), # 使用 AI 生成的心得
                "name": video_data.get('ai_title', video_data.get('title', '')), # 使用 AI 標題或原始標題
                "url": page_url,
                "datePublished": datetime.now().strftime('%Y-%m-%d'), # 評論發布日期（生成日期）
                # "reviewRating": { # 如果有評分可以加入
                #     "@type": "Rating",
                #     "ratingValue": "5", # 示例評分
                #     "bestRating": "5"
                # }
            },
            {
                "@type": "BreadcrumbList",
                "itemListElement": [
                    {
                        "@type": "ListItem",
                        "position": 1,
                        "name": "Homepage" if lang == 'en' else "首頁",
                        "item": f"{base_url}/index_{lang}.html"
                    },
                    # 可以根據分類或女優添加更多層級
                    {
                        "@type": "ListItem",
                        "position": 2,
                        "name": video_data.get('title', ''),
                        "item": page_url
                    }
                ]
            }
        ]
    }
    # 清理掉值為 None 或空字串/列表的鍵
    def clean_empty(d):
        if isinstance(d, dict):
            cleaned = {k: clean_empty(v) for k, v in d.items() if v is not None and v != '' and (not isinstance(v, list) or v)}
            return cleaned if cleaned else None # 如果字典變空，返回 None
        elif isinstance(d, list):
            cleaned = [clean_empty(i) for i in d if i is not None and i != '']
            return cleaned if cleaned else None # 如果列表變空，返回 None
        else:
            return d

    cleaned_schema = clean_empty(schema)
    # 確保 @graph 存在且不為空
    if cleaned_schema and cleaned_schema.get('@graph'):
        cleaned_schema['@graph'] = [item for item in cleaned_schema['@graph'] if item] # 移除 @graph 中的 None
        if not cleaned_schema['@graph']:
             return None # 如果 @graph 為空，不生成 schema
    elif not cleaned_schema:
        return None # 如果整個 schema 為空
        
    return json.dumps(cleaned_schema, indent=2, ensure_ascii=False)

# --- 獲取資料 --- 
print("Fetching top 3 video data from database...") # Updated print message
video_data_list = fetch_top_video_details() # Removed limit and offset

if not video_data_list:
    print("無法從資料庫獲取影片資料，腳本終止。")
    exit()

# --- 輔助函數：生成安全的文件名 (從 render_static_actress.py 複製) ---
def sanitize_filename(name):
    """將名稱轉換為安全的文件名"""
    # 移除或替換不安全字符
    name = re.sub(r'[\\/*?:".<>|]', '', name)
    # 將空格替換為下劃線
    name = name.replace(' ', '_')
    # 限制長度 (可選)
    return name[:100] # 限制文件名長度為 100

# --- DeepSeek API 函數 (保持不變) ---
def generate_content_with_deepseek(prompt):
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}"
    }
    data = {
        "model": "deepseek-chat", # 或其他指定模型
        "messages": [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt}
        ],
        "max_tokens": 500, # 根據需要調整
        "temperature": 0.7 # 根據需要調整
    }
    try:
        response = requests.post(DEEPSEEK_API_URL, headers=headers, json=data)
        response.raise_for_status() # 檢查請求是否成功
        result = response.json()
        # 提取生成的內容，具體路徑可能依 API 回應格式調整
        if result.get('choices') and len(result['choices']) > 0:
            return result['choices'][0].get('message', {}).get('content', '').strip()
        else:
            print("Error: Unexpected API response format.")
            print(result)
            return "(AI content generation failed)"
    except requests.exceptions.RequestException as e:
        print(f"Error calling DeepSeek API: {e}")
        if response:
            print(f"Response status: {response.status_code}")
            print(f"Response text: {response.text}")
        return "(AI content generation failed due to network error)"
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        return "(AI content generation failed due to unexpected error)"

# --- 設定 Jinja2 ---
# 確保 templates 目錄在腳本執行路徑下
env = Environment(loader=FileSystemLoader('templates'))
template = env.get_template('detail_static.html') # Load template once

# --- 遍歷影片資料並生成內容與頁面 ---
os.makedirs('output', exist_ok=True)

for video_data in video_data_list:
    print(f"\n--- Processing video: {video_data['id']} ---")

    # --- 生成 AI 內容 ---
    print("Generating AI content...")

    # 使用從資料庫獲取的資料
    video_title = video_data.get('title', '未知標題')
    video_code = video_data.get('id', 'N/A')
    actress_name = video_data.get('actress', '未知演員') # 使用映射後的單數 actress
    genres_list = video_data.get('genres', [])
    base_description = video_data.get('base_info_for_ai', '')

    # 提取幾個關鍵類型詞 (例如前3個)
    keywords = ', '.join(genres_list[:3]) if genres_list else '無'
    # 將關鍵字列表轉換為英文 (如果需要，或讓 AI 處理)
    # For simplicity, we assume AI can handle the keywords even if they contain non-English chars in the prompt
    # Or, ideally, fetch/map English keywords if available in the DB
    keywords_en = ', '.join(genres_list[:3]) if genres_list else 'None' # Basic fallback

    # --- 新增：為英文版準備英文變數 ---
    actress_name_en = actress_name if actress_name != '未知演員' else 'Unknown Actress'
    # 如果 video_title 可能是中文，也可以考慮為英文 prompt 提供一個備用標題或指示 AI 忽略
    # video_title_for_en_prompt = video_title # 暫時直接使用，依賴 AI 處理
    # base_description_en = base_description # 假設描述是多語言或 AI 能處理

    # --- 新增：AI 改寫標題 (中文用) ---
    rewrite_title_prompt_zh = f"請將以下影片標題 '{video_title}' 用稍微不同的方式表達，保持意思和長度相似，作為網頁標題使用。"
    print("Rewriting title with AI (Chinese)...")
    ai_rewritten_title_zh = generate_content_with_deepseek(rewrite_title_prompt_zh)
    # 如果 AI 改寫失敗，則退回使用原始標題
    if "failed" in ai_rewritten_title_zh:
        print("AI title rewrite failed (Chinese), using original title.")
        ai_rewritten_title_zh = video_title
    # --- 結束：AI 改寫標題 (中文用) ---

    # --- 新增：AI 生成英文標題 --- 
    generate_title_prompt_en = f"Generate a catchy and appropriate English title for a JAV review webpage based on the following information. The title should be concise and appealing to an English-speaking audience. Video Code: {video_code}, Actress: {actress_name_en}, Keywords: {keywords_en}, Original Title (for context, may be non-English): {video_title}"
    print("Generating English title with AI...")
    ai_generated_title_en = generate_content_with_deepseek(generate_title_prompt_en)
    # 如果 AI 生成失敗，則使用原始標題或預設值
    if "failed" in ai_generated_title_en or not ai_generated_title_en:
        print("AI English title generation failed, using a default title.")
        # Attempt to use original title, or a generic fallback
        ai_generated_title_en = video_title if video_title else f"Review: {video_code}" 
    # --- 結束：AI 生成英文標題 ---

    # 新的 Momo Prompt (中文)
    momo_prompt_zh = f"""
    你是一位 21 歲的女大學生，角色人設是「Momo」，她每晚偷看片後，會立刻在手機記事本裡記下自己的觀影碎唸，就像在跟閨蜜抱怨一樣。

    Momo 寫的內容非常口語、很鬆、像講話一樣，有點亂、有點色，但非常真實。這不是影評，而是色到語無倫次的觀後腦袋湯文。

    請幫我寫一篇 400～600 字的碎唸心得。語氣要自然隨便，可以加入 emoji（🥵🙈💦😮‍💨）與語助詞（欸、蛤、我真的…、拜託、誰懂啦 等）。

    請跟著這個感覺來寫：
    1. **一開場先寫你被哪個點打到，崩潰的反應**  
    2. **再描述2～3個畫面或橋段，你覺得超癢、超記得，寫出女優的表現、當下氣氛、你自己被撩到的感受**  
    3. **最後來一句色色的收尾或幻想（像是「他如果對我那樣我直接躺平」）**

    請自然帶入以下資訊，但不要生硬塞關鍵字：
    - 番號：{video_code}
    - 標題：{video_title}
    - 女優：{actress_name}
    - 類型關鍵字：{keywords}

    【影片簡介】{base_description}
    """

    print("Generating Chinese content with Momo prompt...")
    ai_content_zh = generate_content_with_deepseek(momo_prompt_zh)

    # 新的 Momo Prompt (英文)
    translate_prompt_en = f"""You are Momo – a horny 21-year-old college girl who secretly watches JAV every night and writes *raw*, *chaotic*, and *super personal* notes like she’s texting her BFF at 1am. You’re not doing reviews—you’re melting down.

Your tone should be: chaotic, unfiltered, funny, and flirty. You are not writing. You are RANTING. Use emoji like 🥵😮‍💨🙈💦, and lots of fillers like “wait—WHAT??”, “bro pls”, “I screamed.”

Please write a 400–600 word diary-style piece that flows like this:
1. Start with your *brain meltdown* moment. What instantly hit you?
2. Describe 2–3 juicy scenes that broke you (vivid, horny, specific details)
3. End with a spicy fantasy or a flirty one-liner (e.g. “I would’ve let her ruin me too 😮‍💨”)

In the story, casually mention:
- fanhao: {video_code}
- title: {video_title}
- actress: {actress_name_en}
- genres: {keywords_en}

You can imagine you were there, or that this happened to *you*. Be messy, be real, be Momo.

【Video Info – for your context only】
- Fanhao: {video_code}
- Title: {video_title}
- Actress: {actress_name_en}
- Genres: {keywords_en}
- Description: {base_description}
"""

    print("Translating Chinese content to English...")
    ai_content_en = generate_content_with_deepseek(translate_prompt_en)

    # 將 AI 內容存儲到 video_data 中，以便 schema 生成函數使用
    video_data['ai_content'] = ai_content_zh # 暫存中文內容供中文 schema 使用
    video_data['ai_title'] = ai_rewritten_title_zh # 暫存中文標題供中文 schema 使用

    # --- 生成 Schema.org JSON-LD (中文) ---
    print("Generating Schema.org JSON-LD (Chinese)...")
    schema_json_zh = generate_schema_data(video_data, 'zh')

    # 更新 video_data 中的內容為英文版，供英文 schema 使用
    video_data['ai_content'] = ai_content_en
    video_data['ai_title'] = ai_generated_title_en

    # --- 生成 Schema.org JSON-LD (英文) ---
    print("Generating Schema.org JSON-LD (English)...")
    schema_json_en = generate_schema_data(video_data, 'en')

    # 生成 SEO 摘要 (保持不變，但使用 video_title)
    seo_prompt_zh = f"請為影片 '{video_title}' 產生一段約 150 字元的中文 SEO 摘要，包含主要關鍵字，用於網頁 meta description。"
    seo_prompt_en = f"Generate a concise English SEO summary (around 150 characters) for the video '{video_title}', including main keywords like '{keywords_en}' and '{actress_name_en}', suitable for a webpage meta description. The output must be in English only."

    print("Generating SEO summaries...")
    seo_summary_zh = generate_content_with_deepseek(seo_prompt_zh)
    seo_summary_en = generate_content_with_deepseek(seo_prompt_en)

    print("AI content generation and translation complete.")

    # --- 新增：準備女優連結 --- 
    actress_links = []
    if video_data.get('actresses'):
        for actress in video_data['actresses']:
            safe_filename = sanitize_filename(actress)
            # 注意相對路徑，從 detail 頁面指向 actresses 子目錄
            link_zh = f"../actresses/{safe_filename}_zh.html"
            link_en = f"../actresses/{safe_filename}_en.html"
            actress_links.append({'name': actress, 'link_zh': link_zh, 'link_en': link_en})

    # --- 渲染並儲存模板 --- 

    # 渲染中文版本
    html_zh = template.render(
        video=video_data, # 傳遞當前影片的 video_data
        ai_content=ai_content_zh, # 使用合併後的內容
        ai_title=ai_rewritten_title_zh, # 使用中文 AI 改寫後的標題
        schema_json=schema_json_zh, # 新增 schema 資料
        actress_links=actress_links, # 新增：傳遞女優連結列表
        lang='zh'
    )
    output_path_zh = os.path.join('output', f"{video_data['id']}_zh.html")
    with open(output_path_zh, 'w', encoding='utf-8') as f:
        f.write(html_zh)
    print(f"中文靜態心得頁面已產生：{output_path_zh}")

    # 渲染英文版本
    html_en = template.render(
        video=video_data, # 傳遞當前影片的 video_data
        ai_content=ai_content_en, # 使用翻譯後的內容
        ai_title=ai_generated_title_en, # 使用 AI 生成的英文標題
        schema_json=schema_json_en, # 新增 schema 資料
        actress_links=actress_links, # 新增：傳遞女優連結列表
        lang='en'
    )
    output_path_en = os.path.join('output', f"{video_data['id']}_en.html")
    with open(output_path_en, 'w', encoding='utf-8') as f:
        f.write(html_en)
    print(f"英文靜態心得頁面已產生：{output_path_en}")

print("\n所有影片處理完成！")